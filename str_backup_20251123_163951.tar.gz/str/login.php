<?php
session_start();
date_default_timezone_set('America/Argentina/Buenos_Aires');

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Logout
if (isset($_GET['logout'])) {
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p["path"], $p["domain"], $p["secure"], $p["httponly"]
        );
    }
    session_destroy();
    header("Location: login.php");
    exit;
}

$isLogged = (!empty($_SESSION['usuario']));

// Si ya está logueado, ruteo directo
if ($isLogged) {
    $tg  = isset($_SESSION['tipo_global']) ? $_SESSION['tipo_global'] : '';
    $re  = isset($_SESSION['rol_evento']) ? $_SESSION['rol_evento'] : '';
    $eid = isset($_SESSION['evento_id']) ? (int)$_SESSION['evento_id'] : 0;
    if ($eid <= 0) { $eid = 1; }

    if ($tg === 'super_admin') { header("Location: superadmin.php"); exit; }
    if ($tg === 'admin_evento') { header("Location: panel_admin.php"); exit; }
    if ($tg === 'staff_evento' && $re === 'puerta') {
        header("Location: puerta.php?evento_id=".$eid); exit;
    }

    header("Location: panel_admin.php"); exit;
}

$error = "";

// ===== DB =====
$dbFile = __DIR__ . '/save_the_rave.sqlite';
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Throwable $ex) {
    http_response_code(500);
    echo "Error DB: " . e($ex->getMessage());
    exit;
}

// Procesar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = isset($_POST['user']) ? trim($_POST['user']) : '';
    $pass = isset($_POST['pass']) ? (string)$_POST['pass'] : '';

    if ($user === '' || $pass === '') {
        $error = "Completá usuario y contraseña.";
    } else {

        $stmt = $pdo->prepare("
            SELECT id, username, password, tipo_global, rol_evento, evento_id, activo
            FROM usuarios_admin
            WHERE username = :u
            LIMIT 1
        ");
        $stmt->execute(array(':u' => $user));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row || (int)$row['activo'] !== 1) {
            $error = "Usuario no encontrado o inactivo.";
        } elseif ((string)$row['password'] !== $pass) {
            $error = "Contraseña incorrecta.";
        } else {

            // ✅ Login OK: set de sesión
            $_SESSION['usuario']     = $row['username'];
            $_SESSION['user_id']     = (int)$row['id'];
            $_SESSION['tipo_global'] = $row['tipo_global'];
            $_SESSION['rol_evento']  = $row['rol_evento'];
            $_SESSION['evento_id']   = isset($row['evento_id']) ? (int)$row['evento_id'] : 0;

            $tipo = strtolower(trim($row['tipo_global']));
            $rol  = strtolower(trim((string)$row['rol_evento']));
            $eid  = (int)$_SESSION['evento_id'];
            if ($eid <= 0) { $eid = 1; }

            if ($tipo === 'super_admin')  { header("Location: superadmin.php"); exit; }
            if ($tipo === 'admin_evento') { header("Location: panel_admin.php"); exit; }

            if ($tipo === 'staff_evento') {
                if ($rol === 'puerta') {
                    header("Location: puerta.php?evento_id=".$eid); exit;
                }
                header("Location: panel_admin.php"); exit;
            }

            header("Location: panel_admin.php"); exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login Admin – TICKEX</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{
      font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
      background:#0b0b0b;color:#f5f5f5;min-height:100vh;
      display:flex;align-items:center;justify-content:center;padding:20px;
    }
    .card{
      width:100%;max-width:420px;background:#151515;border-radius:16px;
      padding:24px;box-shadow:0 18px 35px rgba(0,0,0,.6);
    }
    h1{fon
    p.sub{font-size:.9rem;color:#aaa;margin-bottom:18px;text-align:center;}
    .field{margin-bottom:14px;}
    label{display:block;font-size:.85rem;margin-bottom:4px;color:#ccc;}
    input{
      width:100%;padding:9px 10px;border-radius:10px;border:1px solid #333;
      background:#111;color:#f5f5f5;font-size:.9rem;
    }
    button{
      width:100%;margin-top:8px;padding:10px 0;border:none;border-radius:999px;
      background:#d71d24;color:white;font-weight:600;font-size:.95rem;cursor:pointer;
    }
    button:hover{filter:brightness(1.08);}
    .error{
      margin-top:10px;padding:8px 10px;border-radius:8px;background:#3a1114;
      color:#ffb3b3;font-size:.85rem;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Login Admin – TICKEX</h1>
    <p class="sub">Ingresá tu usuario y contraseña.</p>

    <form method="post" action="login.php">
      <div class="field">
        <label>Usuario</label>
        <input type="text" name="user" autocomplete="off" required />
      </div>

      <div class="field">
        <label>Contraseña</label>
        <input type="password" name="pass" autocomplete="off" required />
      </div>

      <button type="submit">Entrar</button>

      <?php if ($error): ?>
        <div class="error"><?php echo e($error); ?></div>
      <?php endif; ?>
    </form>
  </div>
</body>
</html>
