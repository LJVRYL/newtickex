<?php
$dbFile = __DIR__ . '/save_the_rave.sqlite';

if (!file_exists($dbFile)) {
    die('Base de datos no encontrada.');
}

$codigo = isset($_GET['c']) ? trim($_GET['c']) : '';
if ($codigo === '') {
    http_response_code(400);
    echo 'Falta el código (parámetro c).';
    exit;
}

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Error al leer la base: ' . htmlspecialchars($e->getMessage()));
}

$stmt = $pdo->prepare("SELECT * FROM entradas WHERE codigo = :codigo LIMIT 1");
$stmt->execute(array(':codigo' => $codigo));
$entrada = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$entrada) {
    http_response_code(404);
    echo 'Entrada no encontrada para ese código.';
    exit;
}

// Helper tipo
function pretty_tipo($tipoRaw) {
    $tipo = $tipoRaw;
    if ($tipo === null || $tipo === '') $tipo = 'desconocido';

    switch ($tipo) {
        case 'ANTICIPADA':    return 'Anticipada';
        case 'FREE':          return 'FREE (lista)';
        case 'PUERTA_10000':  return 'Lista puerta $10.000';
        case 'PUERTA_15000':  return 'Lista puerta $15.000';
        case 'OTRO_NOMBRE':   return 'Otro nombre (ver quién pagó)';
        default:              return ucfirst($tipo);
    }
}

$nombre    = $entrada['nombre'];
$tipoDesc  = pretty_tipo($entrada['tipo']);
$checked   = ((int)$entrada['checked_in'] === 1);
$codigoStr = $entrada['codigo'];

// URL real de checkin (lo que se va a leer del QR)
$checkinUrl = 'https://str.tickex.com.ar/checkin.php?c=' . urlencode($codigoStr);

// Generamos QR con api.qrserver.com
$qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=' . urlencode($checkinUrl);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Entrada – Save The Rave</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #000;
      color: #f5f5f5;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .card {
      width: 100%;
      max-width: 420px;
      background: #111;
      border-radius: 16px;
      padding: 20px 22px;
      box-shadow: 0 18px 36px rgba(0,0,0,0.6);
      text-align: center;
    }
    h1 {
      font-size: 1.4rem;
      margin-bottom: 8px;
    }
    .subtitle {
      font-size: 0.9rem;
      color: #bbb;
      margin-bottom: 12px;
    }
    .chip-tipo {
      display: inline-block;
      padding: 2px 10px;
      border-radius: 999px;
      font-size: 0.8rem;
      background: #222;
      color: #eee;
      margin-bottom: 6px;
    }
    .status {
      display: inline-block;
      margin: 10px 0 14px;
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 0.8rem;
    }
    .status-ok {
      background: #234326;
      color: #8df09e;
    }
    .status-pend {
      background: #443222;
      color: #ffd38a;
    }
    .qr {
      margin: 12px auto 8px;
    }
    .code {
      font-size: 0.85rem;
      color: #aaa;
      margin-top: 6px;
    }
    .small {
      font-size: 0.8rem;
      color: #888;
      margin-top: 8px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Entrada digital</h1>
    <div class="subtitle">SAVE THE RAVE</div>

    <div class="chip-tipo"><?php echo htmlspecialchars($tipoDesc); ?></div>

    <div>
      <strong>Nombre en lista:</strong><br />
      <?php echo htmlspecialchars($nombre); ?>
    </div>

    <div class="status <?php echo $checked ? 'status-ok' : 'status-pend'; ?>">
      <?php echo $checked ? 'Ya chequeada en puerta' : 'Todavía no se usó'; ?>
    </div>

    <div class="qr">
      <img src="<?php echo htmlspecialchars($qrUrl); ?>" alt="QR entrada" width="260" height="260" />
    </div>

    <div class="code">
      Código: <code><?php echo htmlspecialchars($codigoStr); ?></code>
    </div>

    <div class="small">
   
      No lo compartas con terceros.
    </div>
  </div>
</body>
</html>
