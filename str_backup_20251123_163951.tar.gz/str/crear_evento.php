<?php
session_start();

// Sólo super_admin o admin_evento pueden crear eventos
if (empty($_SESSION['usuario'])) {
    header('Location: admin.php');
    exit;
}

$dbFile = __DIR__ . '/save_the_rave.sqlite';
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Throwable $e) {
    http_response_code(500);
    echo "Error DB: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    exit;
}

// Cargar usuario
$stmtUser = $pdo->prepare("
    SELECT id, username, tipo_global
    FROM usuarios_admin
    WHERE username = :u
    LIMIT 1
");
$stmtUser->execute([':u' => $_SESSION['usuario']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user || !in_array($user['tipo_global'], ['super_admin', 'admin_evento'], true)) {
    header('Location: admin.php');
    exit;
}

function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

$error = '';
$okMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre      = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $slug        = isset($_POST['slug']) ? trim($_POST['slug']) : '';
    $fechaDesde  = isset($_POST['fecha_desde']) ? trim($_POST['fecha_desde']) : '';
    $fechaHasta  = isset($_POST['fecha_hasta']) ? trim($_POST['fecha_hasta']) : '';
    $descripcion = isset($_POST['descripcion']) ? trim($_POST['descripcion']) : '';

    // Tipo de entrada inicial
    $te_nombre      = isset($_POST['te_nombre']) ? trim($_POST['te_nombre']) : '';
    $te_tipo        = isset($_POST['te_tipo']) ? trim($_POST['te_tipo']) : 'free';
    $te_precio      = isset($_POST['te_precio']) ? (int)$_POST['te_precio'] : 0;
    $te_cant_total  = isset($_POST['te_cant_total']) ? (int)$_POST['te_cant_total'] : 0;
    $te_hora_limite = isset($_POST['te_hora_limite']) ? trim($_POST['te_hora_limite']) : '';

    // Validaciones básicas
    if ($nombre === '' || $slug === '') {
        $error = 'Nombre y slug son obligatorios.';
    } elseif (!preg_match('/^[a-z0-9\-]+$/', $slug)) {
        $error = 'El slug solo puede tener minúsculas, números y guiones (a-z, 0-9, -).';
    } elseif ($te_nombre === '') {
        $error = 'Debés definir al menos un tipo de entrada (nombre).';
    } elseif ($te_tipo === 'paga' && $te_precio <= 0) {
        $error = 'Para entradas pagas, el precio debe ser mayor a 0.';
    } else {
        // Manejar flyer (opcional)
        $flyerFilename = null;

        if (isset($_FILES['flyer']) && $_FILES['flyer']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['flyer']['error'] === UPLOAD_ERR_OK) {
                $tmpName = $_FILES['flyer']['tmp_name'];
                $size    = (int)$_FILES['flyer']['size'];

                if ($size > 2 * 1024 * 1024) { // 2MB
                    $error = 'El flyer no puede pesar más de 2 MB.';
                } else {
                    $originalName = $_FILES['flyer']['name'];
                    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

                    if (!in_array($ext, ['png', 'jpg', 'jpeg'], true)) {
                        $error = 'Solo se permiten imágenes PNG o JPG.';
                    } else {
                        $safeBase = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $originalName);
                        $newName  = time() . '_' . $safeBase;
                        $destPath = __DIR__ . '/event_flyers/' . $newName;

                        if (!move_uploaded_file($tmpName, $destPath)) {
                            $error = 'No se pudo guardar el flyer en el servidor.';
                        } else {
                            $flyerFilename = 'event_flyers/' . $newName;
                        }
                    }
                }
            } else {
                $error = 'Error al subir el flyer (código: ' . (int)$_FILES['flyer']['error'] . ').';
            }
        }

        if (!$error) {
            try {
                $pdo->beginTransaction();

                // Insertar evento (SIN creado_por_admin_id)
                $stmtEv = $pdo->prepare("
                    INSERT INTO eventos
                        (nombre, slug, descripcion, flyer_filename, fecha_desde, fecha_hasta, creado_en)
                    VALUES
                        (:nombre, :slug, :descripcion, :flyer, :fdesde, :fhasta, datetime('now'))
                ");
                $stmtEv->execute([
                    ':nombre'      => $nombre,
                    ':slug'        => $slug,
                    ':descripcion' => $descripcion,
                    ':flyer'       => $flyerFilename,
                    ':fdesde'      => $fechaDesde !== '' ? $fechaDesde : null,
                    ':fhasta'      => $fechaHasta !== '' ? $fechaHasta : null,
                ]);

                $eventoId = (int)$pdo->lastInsertId();

                // Insertar tipo de entrada inicial
                $stmtTE = $pdo->prepare("
                    INSERT INTO tipos_entrada
                        (evento_id, nombre, tipo, precio, cantidad_total, cantidad_disponible, hora_limite, reglas_precio)
                    VALUES
                        (:evento_id, :nombre, :tipo, :precio, :ctotal, :cdisp, :hora_limite, :reglas)
                ");
                $stmtTE->execute([
                    ':evento_id'   => $eventoId,
                    ':nombre'      => $te_nombre,
                    ':tipo'        => $te_tipo,
                    ':precio'      => ($te_tipo === 'paga' ? $te_precio : 0),
                    ':ctotal'      => $te_cant_total,
                    ':cdisp'       => $te_cant_total,
                    ':hora_limite' => $te_hora_limite !== '' ? $te_hora_limite : null,
                    ':reglas'      => null, // Futuro: tandas de precio en JSON
                ]);

                $pdo->commit();

                $okMsg = "Evento creado correctamente (ID #{$eventoId}, slug '{$slug}').";
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = 'Error al crear el evento: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Crear evento – TICKEX</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      margin:0;
      padding:16px;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background:#020617;
      color:#e5e7eb;
    }
    h1 {
      font-size:1.3rem;
      margin:0 0 6px;
    }
    .sub {
      font-size:0.85rem;
      color:#9ca3af;
      margin-bottom:14px;
    }
    .btn-link {
      display:inline-block;
      padding:6px 10px;
      border-radius:999px;
      background:#111827;
      color:#e5e7eb;
      text-decoration:none;
      font-size:0.8rem;
      margin-right:8px;
      border:1px solid #1f2937;
    }
    .btn-link:hover { background:#1f2937; }
    .card {
      background:#020617;
      border-radius:14px;
      padding:14px 16px;
      border:1px solid #1f2937;
      box-shadow:0 10px 25px rgba(0,0,0,0.5);
      margin-top:12px;
    }
    label {
      font-size:0.8rem;
      display:block;
      margin-bottom:4px;
      color:#9ca3af;
    }
    input[type="text"],
    input[type="date"],
    input[type="number"],
    textarea,
    input[type="file"],
    select {
      width:100%;
      padding:6px 8px;
      border-radius:8px;
      border:1px solid #374151;
      background:#020617;
      color:#e5e7eb;
      font-size:0.85rem;
      margin-bottom:8px;
    }
    textarea { min-height:70px; resize:vertical; }
    button[type="submit"] {
      margin-top:6px;
      padding:8px 14px;
      border-radius:999px;
      border:none;
      background:#d71d24;
      color:#fff;
      font-size:0.9rem;
      font-weight:600;
      cursor:pointer;
    }
    button[type="submit"]:hover { filter:brightness(1.05); }
    .msg-error {
      margin-top:8px;
      padding:8px 10px;
      border-radius:8px;
      background:#7f1d1d;
      color:#fecaca;
      font-size:0.8rem;
    }
    .msg-ok {
      margin-top:8px;
      padding:8px 10px;
      border-radius:8px;
      background:#14532d;
      color:#bbf7d0;
      font-size:0.8rem;
    }
  </style>
</head>
<body>

<div>
  <a class="btn-link" href="panel_str.php">⬅ Volver al panel STR</a>
  <?php if ($user['tipo_global'] === 'super_admin'): ?>
    <a class="btn-link" href="superadmin.php">SuperAdmin</a>
  <?php endif; ?>
</div>

<h1>Crear nuevo evento</h1>
<div class="sub">
  Usuario: <strong><?php echo e($user['username']); ?></strong> (<?php echo e($user['tipo_global']); ?>)<br>
  Esta versión crea el evento + 1 tipo de entrada inicial.
</div>

<?php if ($error): ?>
  <div class="msg-error"><?php echo e($error); ?></div>
<?php elseif ($okMsg): ?>
  <div class="msg-ok"><?php echo e($okMsg); ?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="card">
    <h2 style="font-size:1rem;margin:0 0 8px;">Datos del evento</h2>

    <label for="nombre">Nombre del evento</label>
    <input type="text" id="nombre" name="nombre" required>

    <label for="slug">Slug / URL corta (ej: "str2", "retro")</label>
    <input type="text" id="slug" name="slug" required placeholder="solo minúsculas, números y -">

    <label for="descripcion">Descripción breve (opcional)</label>
    <textarea id="descripcion" name="descripcion" placeholder="Texto descriptivo del evento..."></textarea>

    <label>Fechas del evento (desde / hasta)</label>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <div style="flex:1 1 140px;">
        <label for="fecha_desde">Desde</label>
        <input type="date" id="fecha_desde" name="fecha_desde">
      </div>
      <div style="flex:1 1 140px;">
        <label for="fe
        <input type="date" id="fecha_hasta" name="fecha_hasta">
      </div>
    </div>

    <label for="flyer">Flyer del evento (PNG/JPG, máx. 2MB)</label>
    <input type="file" id="flyer" name="flyer" accept="image/png,image/jpeg">
  </div>

  <div class="card">
    <h2 style="font-size:1rem;margin:0 0 8px;">Tipo de entrada inicial</h2>

    <label for="te_nombre">Nombre de la entrada</label>
    <input type="text" id="te_nombre" name="te_nombre" required placeholder="Ej: General FREE, Anticipada 1, etc.">

    <label for="te_tipo">Tipo</label>
    <select id="te_tipo" name="te_tipo">
      <option value="free">Entrada FREE</option>
      <option value="paga">Entrada PAGA</option>
    </select>

    <label for="te_precio">Precio (solo aplica a entradas pagas)</label>
    <input type="number" id="te_precio" name="te_precio" min="0" step="1" placeholder="Ej: 1000">

    <label for="te_cant_total">Cantidad total disponible</label>
    <input type="number" id="te_cant_total" name="te_cant_total" min="0" step="1" value="0">

    <label for="te_hora_limite">Límite de hora para ingreso (texto libre)</label>
    <input type="text" id="te_hora_limite" name="te_hora_limite" placeholder="Ej: hasta las 02:00, todo el evento, etc.">

    <p style="font-size:0.8rem;color:#9ca3af;margin-top:6px;">
      Las <strong>tandas de precio</strong> (subir precio después de X ventas) las vamos a modelar dentro de
      <code>reglas_precio</code> más adelante, para no mezclar demasiadas cosas de golpe.
    </p>
  </div>

  <button type="submit">Crear evento</button>
</form>

</body>
</html>
