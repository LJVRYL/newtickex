<?php
// nueva_entrada.php
// Formulario simple para agregar entradas manualmente desde la puerta.

$dbFile = __DIR__ . '/save_the_rave.sqlite';
if (!file_exists($dbFile)) {
    die('Base de datos no encontrada.');
}

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Error al conectar a la base: ' . htmlspecialchars($e->getMessage()));
}

// Tipos válidos
$tiposValidos = [
    'FREE'         => 'Entrada FREE',
    'ANTICIPADA'   => 'Entrada anticipada',
    'PUERTA_10000' => 'Lista puerta $10.000',
    'PUERTA_15000' => 'Lista puerta $15.000',
    'OTRO_NOMBRE'  => 'Entrada con otro nombre',
];

$errores = [];
$ok = false;
$nombre = '';
$tipoSeleccionado = 'FREE';
$pagoRaw = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $tipoSeleccionado = $_POST['tipo'] ?? 'FREE';
    $pagoRaw = trim($_POST['pago'] ?? '');

    if ($nombre === '') {
        $errores[] = 'El nombre es obligatorio.';
    }
    if (!isset($tiposValidos[$tipoSeleccionado])) {
        $errores[] = 'Tipo de entrada inválido.';
    }

    // Monto pagado (en pesos, entero)
    $monto = 0;
    if ($pagoRaw !== '') {
        $tmp = str_replace(',', '.', $pagoRaw);
        if (!is_numeric($tmp)) {
            $errores[] = 'El monto pagado debe ser un número (podés usar . o , para decimales).';
        } else {
            $monto = (int) round((float)$tmp);
        }
    }

    if (empty($errores)) {
        $dt = new DateTime('now', new DateTimeZone('America/Argentina/Buenos_Aires'));
        $fecha = $dt->format('Y-m-d H:i:s');

        $maxIntentos = 5;
        $okInsercion = false;

        for ($i = 0; $i < $maxIntentos; $i++) {
            if (function_exists('random_bytes')) {
                $codigo = bin2hex(random_bytes(5)); // 10 chars
            } else {
                $codigo = substr(sha1(uniqid('', true)), 0, 10);
            }

            try {
                $stmt = $pdo->prepare("
                    INSERT INTO entradas
                        (nombre, email, fecha_registro, codigo, checked_in, checked_in_at, tipo, monto_pagado)
                    VALUES
                        (:nombre, '', :fecha, :codigo, 0, NULL, :tipo, :monto)
                ");
                $stmt->execute([
                    ':nombre' => $nombre,
                    ':fecha'  => $fecha,
                    ':codigo' => $codigo,
                    ':tipo'   => $tipoSeleccionado,
                    ':monto'  => $monto,
                ]);
                $okInsercion = true;
                $ok = true;
                break;
            } catch (Exception $e) {
                $msg = $e->getMessage();
                if (stripos($msg, 'UNIQUE') !== false) {
                    // colisión de código, probamos otro
                    continue;
                } else {
                    $errores[] = 'Error al guardar en la base: ' . $msg;
                    break;
                }
            }
        }

        if ($okInsercion) {
            // Limpiamos el formulario después de guardar
            $nombre = '';
            $pagoRaw = '';
            $tipoSeleccionado = 'FREE';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Save The Rave – Nueva entrada</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #000;
      color: #f5f5f5;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      display: flex;
      justify-content: center;
      align-items: flex-start;
    }
    .card {
      width: 100%;
      max-width: 480px;
      background: #111;
      border-radius: 16px;
      padding: 20px 22px;
      box-shadow: 0 18px 36px rgba(0,0,0,0.6);
    }
    h1 {
      font-size: 1.4rem;
      margin-bottom: 8px;
    }
    p.desc {
      font-size: 0.9rem;
      color: #bbb;
      margin-bottom: 16px;
    }
    .back-link {
      display: inline-block;
      margin-bottom: 12px;
      font-size: 0.85rem;
      color: #8ec6ff;
      text-decoration: none;
    }
    .back-link:hover {
      text-decoration: underline;
    }
    .field {
      margin-bottom: 12px;
    }
    label {
      display: block;
      font-size: 0.85rem;
      margin-bottom: 4px;
      color: #ccc;
    }
    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px 10px;
      border-radius: 8px;
      border: 1px solid #333;
      background: #181818;
      color: #f5f5f5;
      font-size: 0.95rem;
    }
    input[type="text"]:focus,
    input[type="number"]:focus,
    select:focus {
      outline: none;
      border-color: #42a5ff;
      box-shadow: 0 0 0 1px rgba(66,165,255,0.5);
    }
    .help {
      font-size: 0.8rem;
      color: #888;
      margin-top: 2px;
    }
    .btn-submit {
      width: 100%;
      padding: 10px 14px;
      border-radius: 999px;
      border: none;
      font-size: 0.95rem;
      font-weight: 600;
      letter-spacing: 0.02em;
      cursor: pointer;
      background: linear-gradient(135deg, #ff4ecd, #7f5dff);
      color: #fff;
      margin-top: 8px;
    }
    .btn-submit:hover {
      opacity: 0.95;
    }
    .alert-ok {
      background: #12351a;
      border-radius: 8px;
      padding: 8px 10px;
      font-size: 0.85rem;
      color: #a0f3b1;
      margin-bottom: 10px;
    }
    .alert-error {
      background: #3c1212;
      border-radius: 8px;
      padding: 8px 10px;
      font-size: 0.85rem;
      color: #ffb3b3;
      margin-bottom: 10px;
    }
    ul.error-list {
      margin: 4px 0 0;
      padding-left: 18px;
    }
  </style>
</head>
<body>
  <div class="card">
    <a href="admin.php" class="back-link">← Volver al panel</a>
    <h1>Nueva entrada (puerta)</h1>
    <p class="desc">
      Cargá manualmente a alguien que entra: nombre, tipo de entrada
      y cuánto pagó (si corresponde).
    </p>

    <?php if ($ok): ?>
      <div class="alert-ok">
        ✅ Entrada guardada correctamente.
      </div>
    <?php endif; ?>

    <?php if (!empty($errores)): ?>
      <div class="alert-error">
        Ocurrieron estos problemas:
        <ul class="error-list">
          <?php foreach ($errores as $err): ?>
            <li><?php echo htmlspecialchars($err); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" action="nueva_entrada.php">
      <div class="field">
        <label for="nombre">Nombre / alias</label>
        <input
          type="text"
          id="nombre"
          name="nombre"
          required
          value="<?php echo htmlspecialchars($nombre); ?>"
        />
      </div>

      <div class="field">
        <label for="tipo">Tipo de entrada</label>
        <select id="tipo" name="tipo">
          <?php foreach ($tiposValidos as $valor => $label): ?>
            <option value="<?php echo htmlspecialchars($valor); ?>"
              <?php echo ($valor === $tipoSeleccionado) ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($label); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="field">
        <label for="pago">Pago (en pesos)</label>
        <input
          type="text"
          id="pago"
          name="pago"
          placeholder="Ej: 0, 10000, 15000..."
          value="<?php echo htmlspecialchars($pagoRaw); ?>"
        />
        <div class="help">
          Dejalo en blanco o 0 si es invitado / FREE.
        </div>
      </div>

      <button type="submit" class="btn-submit">
        Guardar entrada
      </button>
    </form>
  </div>
</body>
</html>
