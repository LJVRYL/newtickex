<?php
session_start();

// Resolver usuario de sesión
$sessionUser = null;
if (!empty($_SESSION['usuario'])) {
    $sessionUser = $_SESSION['usuario'];
} elseif (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) {
    // Compatibilidad con el login viejo de admin.php
    $sessionUser = 'AdminSTR';
}

if ($sessionUser === null) {
    header('Location: admin.php');
    exit;
}

$dbFile = __DIR__ . '/save_the_rave.sqlite';
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Throwable $e) {
    http_response_code(500);
    echo "Error DB: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    exit;
}

// Cargar usuario actual
$stmt = $pdo->prepare("
    SELECT id, username, tipo_global, nombre, email, dni, cbu, avatar_filename
    FROM usuarios_admin
    WHERE username = :u
    LIMIT 1
");
$stmt->execute([':u' => $sessionUser]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    http_response_code(403);
    echo "Usuario no encontrado.";
    exit;
}

function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

$error = '';
$okMsg = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $email  = isset($_POST['email']) ? trim($_POST['email']) : '';
    $dni    = isset($_POST['dni']) ? trim($_POST['dni']) : '';
    $cbu    = isset($_POST['cbu']) ? trim($_POST['cbu']) : '';

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'El email no tiene un formato válido.';
    }

    $avatarFilename = $user['avatar_filename'];

    // Manejar subida de avatar (opcional)
    if (!$error && isset($_FILES['avatar']) && $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['avatar']['tmp_name'];
            $size    = (int)$_FILES['avatar']['size'];

            if ($size > 2 * 1024 * 1024) {
                $error = 'La imagen de perfil no puede pesar más de 2 MB.';
            } else {
                $info = getimagesize($tmpName);
                if ($info === false) {
                    $error = 'El archivo subido no es una imagen válida.';
                } else {
                    $mime = $info['mime'];
                    $ext  = null;
                    if ($mime === 'image/png') {
                        $ext = 'png';
                    } elseif ($mime === 'image/jpeg') {
                        $ext = 'jpg';
                    } else {
                        $error = 'Solo se permiten imágenes PNG o JPG.';
                    }

                    if (!$error) {
                        $dir = __DIR__ . '/avatars';
                        if (!is_dir($dir)) {
                            mkdir($dir, 0775, true);
                        }
                        $safeBase = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $_FILES['avatar']['name']);
                        $newName  = 'u'.$user['id'].'_'.time().'_'.$safeBase;
                        $destPath = $dir . '/' . $newName;

                        if (!move_uploaded_file($tmpName, $destPath)) {
                            $error = 'No se pudo guardar la imagen en el servidor.';
                        } else {
                            $avatarFilename = 'avatars/' . $newName;
                        }
                    }
                }
            }
        } else {
            $error = 'Error al subir la imagen (código: ' . (int)$_FILES['avatar']['error'] . ').';
        }
    }

    if (!$error) {
        try {
            $stmtUpd = $pdo->prepare("
                UPDATE usuarios_admin
                SET nombre = :nombre,
                    email  = :email,
                    dni    = :dni,
                    cbu    = :cbu,
                    avatar_filename = :avatar
                WHERE id = :id
            ");
            $stmtUpd->execute([
                ':nombre' => $nombre !== '' ? $nombre : null,
                ':email'  => $email  !== '' ? $email  : null,
                ':dni'    => $dni    !== '' ? $dni    : null,
                ':cbu'    => $cbu    !== '' ? $cbu    : null,
                ':avatar' => $avatarFilename,
                ':id'     => $user['id'],
            ]);

            $okMsg = 'Perfil actualizado correctamente.';

            // Refrescar datos
            $user['nombre']          = $nombre;
            $user['email']           = $email;
            $user['dni']             = $dni;
            $user['cbu']             = $cbu;
            $user['avatar_filename'] = $avatarFilename;
        } catch (Throwable $e) {
            $error = 'Error al guardar el perfil: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Mi perfil – <?php echo e($user['username']); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      margin:0;
      padding:16px;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background:#020617;
      color:#e5e7eb;
    }
    h1 {
      margin:0 0 6px;
      font-size:1.3rem;
    }
    .sub {
      font-size:0.85rem;
      color:#9ca3af;
      margin-bottom:14px;
    }
    .btn-link {
      display:inline-block;
      padding:6px 10px;
      border-radius:999px;
      background:#111827;
      color:#e5e7eb;
      text-decoration:none;
      font-size:0.8rem;
      margin-right:8px;
      border:1px solid #1f2937;
    }
    .btn-link:hover { background:#1f2937; }
    .card {
      background:#020617;
      border-radius:14px;
      padding:14px 16px;
      border:1px solid #1f2937;
      box-shadow:0 10px 25px rgba(0,0,0,0.5);
      max-width:640px;
      margin-top:10px;
    }
    label {
      font-size:0.8rem;
      display:block;
      margin-bottom:4px;
      color:#9ca3af;
    }
    input[type="text"],
    input[type="email"],
    input[type="file"] {
      width:100%;
      padding:6px 8px;
      border-radius:8px;
      border:1px solid #374151;
      background:#020617;
      color:#e5e7eb;
      font-size:0.85rem;
      margin-bottom:8px;
    }
    button[type="submit"] {
      margin-top:6px;
      padding:8px 14px;
      border-radius:999px;
      border:none;
      background:#d71d24;
      color:#fff;
      font-size:0.9rem;
      font-weight:600;
      cursor:pointer;
    }
    button[type="submit"]:hover { filter:brightness(1.05); }
    .msg-error {
      margin-top:8px;
      padding:8px 10px;
      border-radius:8px;
      background:#7f1d1d;
      color:#fecaca;
      font-size:0.8rem;
      max-width:640px;
    }
    .msg-ok {
      margin-top:8px;
      padding:8px 10px;
      border-radius:8px;
      background:#14532d;
      color:#bbf7d0;
      font-size:0.8rem;
      max-width:640px;
    }
    .avatar-box {
      display:flex;
      gap:12px;
      align-items:center;
      margin-bottom:8px;
    }
    .avatar-box img {
      width:64px;
      height:64px;
      border-radius:999px;
      object-fit:cover;
      border:1px solid #1f2937;
    }
    .hint {
      font-size:0.75rem;
      color:#6b7280;
      
      margin-bottom:6px;
    }
  </style>
</head>
<body>

<div>
  <a class="btn-link" href="admin.php">⬅ Volver al panel clásico</a>
  <a class="btn-link" href="panel_admin.php">Panel general</a>
</div>

<h1>Mi perfil</h1>
<div class="sub">
  Usuario: <strong><?php echo e($user['username']); ?></strong> (<?php echo e($user['tipo_global']); ?>)
</div>

<?php if ($error): ?>
  <div class="msg-error"><?php echo e($error); ?></div>
<?php elseif ($okMsg): ?>
  <div class="msg-ok"><?php echo e($okMsg); ?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="card">
    <div class="avatar-box">
      <?php if (!empty($user['avatar_filename']) && file_exists(__DIR__ . '/' . $user['avatar_filename'])): ?>
        <img src="<?php echo e($user['avatar_filename']); ?>" alt="Avatar">
      <?php else: ?>
        <div style="width:64px;height:64px;border-radius:999px;background:#111827;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:#9ca3af;">
          <?php echo strtoupper(substr($user['username'],0,1)); ?>
        </div>
      <?php endif; ?>
      <div style="font-size:0.8rem;color:#9ca3af;">
        Podés subir una imagen cuadrada (PNG/JPG, máx. 2MB) para usar como avatar.
      </div>
    </div>

    <label for="avatar">Imagen de perfil</label>
    <input type="file" id="avatar" name="avatar" accept="image/png,image/jpeg">
    <div class="hint">Opcional: si no cargás nada, se mantiene la imagen actual.</div>

    <label for="nombre">Nombre completo</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo e($user['nombre']); ?>">

    <label for="email">Email de contacto</label>
    <input type="email" id="email" name="email" value="<?php echo e($user['email']); ?>">

    <label for="dni">DNI / Documento</label>
    <input type="text" id="dni" name="dni" value="<?php echo e($user['dni']); ?>">

    <label for="cbu">CBU / Cuenta de cobro</label>
    <input type="text" id="cbu" name="cbu" value="<?php echo e($user['cbu']); ?>">

    <button type="submit">Guardar perfil</button>
  </div>
</form>

</body>
</html>
