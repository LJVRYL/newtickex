<?php
session_start();

function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

// ========================
//  AUTH (login nuevo)
// ========================
if (empty($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

$tipoGlobal = isset($_SESSION['tipo_global']) ? $_SESSION['tipo_global'] : '';
$rolEvento  = isset($_SESSION['rol_evento']) ? $_SESSION['rol_evento'] : '';

if (!($tipoGlobal === 'staff_evento' && $rolEvento === 'puerta')) {
    // Si no es puerta, afuera
    header('Location: login.php');
    exit;
}

// ========================
//  EVENTO STAFF
// ========================
$eventoId = 0;
if (isset($_GET['evento_id'])) {
    $eventoId = (int)$_GET['evento_id'];
} elseif (isset($_SESSION['evento_id'])) {
    $eventoId = (int)$_SESSION['evento_id'];
}

// ========================
//  DB
// ========================
$dbFile = __DIR__ . '/save_the_rave.sqlite';

if (!file_exists($dbFile)) {
    http_response_code(500);
    echo "Base de datos no encontrada en: " . e($dbFile);
    exit;
}

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ===== Datos del evento actual (para mostrar en pantalla) =====
$eventoNombre = '';
$eventoSlug   = '';
if (isset($eventoId) && (int)$eventoId > 0) {
    $stmtEvInfo = $pdo->prepare("SELECT nombre, slug FROM eventos WHERE id = :id LIMIT 1");
    $stmtEvInfo->execute(array(':id' => (int)$eventoId));
    $evInfo = $stmtEvInfo->fetch(PDO::FETCH_ASSOC);
    if ($evInfo) {
        $eventoNombre = $evInfo['nombre'];
        $eventoSlug   = $evInfo['slug'];
    }
}
} catch (Exception $ex) {
    http_response_code(500);
    echo "Error DB: " . e($ex->getMessage());
    exit;
}

// ========================
//  FILTROS (igual que admin)
// ========================

// búsqueda libre
$q = '';
if (isset($_GET['q'])) {
    $q = trim($_GET['q']);
}

// filtro tipo
$filtroTipo = '';
if (isset($_GET['tipo'])) {
    $filtroTipo = trim($_GET['tipo']);
}

// filtro estado
$filtroEstado = '';
if (isset($_GET['estado'])) {
    $filtroEstado = trim($_GET['estado']);
}

$where = array();
$params = array();

// Filtro base por evento del staff
if ($eventoId > 0) {
    $where[] = 'evento_id = :evento_id';
    $params[':evento_id'] = $eventoId;
}

// Filtro base por evento del staff
if ($eventoId > 0) {
    $where[] = 'evento_id = :evento_id';
    $params[':evento_id'] = $eventoId;
}

if ($q !== '') {
    $where[] = '(nombre LIKE :q OR email LIKE :q OR codigo LIKE :q)';
    $params[':q'] = '%' . $q . '%';
}

if ($filtroTipo !== '') {
    $where[] = 'tipo = :tipo';
    $params[':tipo'] = $filtroTipo;
}

if ($filtroEstado === 'checkin_ok') {
    $where[] = 'checked_in = 1';
} elseif ($filtroEstado === 'pendiente') {
    $where[] = 'checked_in = 0';
}

$whereSql = '';
if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

// ========================
//  CONTADORES (con filtros)
// ========================

// Total con filtros
$stmtTotal = $pdo->prepare("SELECT COUNT(*) FROM entradas $whereSql");
$stmtTotal->execute($params);
$total = (int)$stmtTotal->fetchColumn();

// Check-ins con filtros (armamos SQL válido siempre)
$checkSql = "SELECT COUNT(*) FROM entradas ";
if ($whereSql !== '') {
    $checkSql .= $whereSql . " AND checked_in = 1";
} else {
    $checkSql .= "WHERE checked_in = 1";
}
$stmtCheck = $pdo->prepare($checkSql);
$stmtCheck->execute($params);
$checkins = (int)$stmtCheck->fetchColumn();

$faltan = max(0, $total - $checkins);

// entradas filtradas
$sql = "SELECT * FROM entradas $whereSql ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// tipos distintos para combo
$tiposStmt = $pdo->query("SELECT DISTINCT tipo FROM entradas ORDER BY tipo ASC");
$tipos = $tiposStmt->fetchAll(PDO::FETCH_COLUMN);

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Check-in – Modo Puerta</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    :root { color-scheme: dark; }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #050505;
      color: #f5f5f5;
      padding: 16px;
    }
    h1 { margin: 0 0 6px; font-size: 1.35rem; }
    .small { font-size: 0.8rem; color: #9ca3af; }

    .top {
      display:flex;
      justify-content:space-between;
      align-items:flex-start;
      gap:12px;
      flex-wrap:wrap;
      margin-bottom:12px;
    }

    .stats {
      display:flex; gap:12px; flex-wrap:wrap;
    }
    .card {
      background:#141414; border-radius:12px; padding:10px 14px;
      box-shadow:0 8px 20px rgba(0,0,0,0.4); min-width:150px;
    }
    .card .label { font-size:0.8rem; color:#aaa; }
    .card .value { margin-top:3px; font-size:1.4rem; font-weight:700; }

    .filters {
      display:flex; gap:8px; flex-wrap:wrap; align-items:center; margin-bottom:8px;
    }
    .filters input, .filters select {
      padding:6px 8px; border-radius:8px; border:
      background:#111; color:#f5f5f5; font-size:0.85rem;
    }
    .filters button {
      padding:7px 12px; border-radius:999px; border:none;
      background:#d71d24; color:#fff; font-size:0.85rem; font-weight:600; cursor:pointer;
    }
    .filters button:hover { filter: brightness(1.05); }

    table {
      width:100%; border-collapse:collapse; margin-top:6px; font-size:0.85rem;
    }
    th, td {
      border-bottom:1px solid #333; padding:6px 8px; vertical-align:middle;
    }
    th {
      background:#181818; text-align:left; position:sticky; top:0; z-index:1;
    }
    tr:hover td { background:#111; }

    .badge-ok {
      display:inline-block; padding:2px 8px; border-radius:999px;
      background:#124221; color:#a6f3b7; font-size:0.75rem;
    }
    .badge-pend {
      display:inline-block; padding:2px 8px; border-radius:999px;
      background:#402018; color:#ffb39a; font-size:0.75rem;
    }

    .btn-link {
      display:inline-block; padding:3px 8px; border-radius:8px;
      background:#222; color:#eee; text-decoration:none; font-size:0.78rem; white-space:nowrap;
    }
    .btn-link:hover { background:#2d2d2d; }
    .btn-checkin { background:#124221; color:#a6f3b7; }
    .btn-checkin:hover { background:#186132; }

    .logout {
      position:fixed; top:10px; right:10px; background:#18181b;
      padding:6px 10px; border-radius:999px; text-decoration:none;
      color:#e5e5e5; font-size:0.75rem;
    }
    .logout:hover { background:#27272a; }

    @media(max-width:800px){
      table{font-size:0.75rem;}
      th,td{padding:4px 5px;}
    }
  </style>
</head>
<body>

<a href="login.php?logout=1" class="logout">Salir</a>

<div class="top">
  <div>
    <h1>Check-in – Modo Puerta</h1>
<?php if (!empty($eventoNombre) || !empty($eventoSlug)): ?>
  <div class="small" style="margin-top:4px;">
    Evento: <strong><?php echo htmlspecialchars($eventoNombre); ?></strong>
    <?php if (!empty($eventoSlug)): ?>
      <span style="color:#9ca3af;">(<?php echo htmlspecialchars($eventoSlug); ?>)</span>
    <?php endif; ?>
  </div>
<?php endif; ?>
    <div class="small">
      Usuario: <strong><?php echo e($_SESSION['usuario']); ?></strong>
    </div>
  </div>

  <div class="stats">
    <div class="card">
      <div class="label">Entradas (con filtros)</div>
      <div class="value"><?php echo (int)$total; ?></div>
    </div>
    <div class="card">
      <div class="label">Check-ins</div>
      <div class="value"><?php echo (int)$checkins; ?></div>
    </div>
    <div class="card">
      <div class="label">Faltan</div>
      <div class="value"><?php echo (int)$faltan; ?></div>
    </div>
  </div>
</div>

<form method="get" class="filters">
  <input
    type="text"
    name="q"
    placeholder="Buscar por nombre, mail o código"
    value="<?php echo e($q); ?>"
  />
  <select name="tipo">
    <option value="">Todos los tipos</option>
    <?php foreach ($tipos as $t): ?>
      <option value="<?php echo e($t); ?>" <?php if ($t === $filtroTipo) echo 'selected'; ?>>
        <?php echo e($t); ?>
      </option>
    <?php endforeach; ?>
  </select>
  <select name="estado">
    <option value="">Todos los estados</option>
    <option value="checkin_ok" <?php if ($filtroEstado === 'checkin_ok') echo 'selected'; ?>>Sólo checkeados</option>
    <option value="pendiente" <?php if ($filtroEstado === 'pendiente') echo 'selected'; ?>>Sólo pendientes</option>
  </select>
  <button type="submit">Filtrar</button>
</form>

<table>
<thead>
<tr>
  <th>#</th>
  <th>Nombre</th>
  <th>Tipo</th>
  <th>Estado</th>
  <th>Check-IN</th>
  <th>Ver entrada</th>
  <th>Email / texto</th>
</tr>
</thead>
<tbody>

<?php foreach ($rows as $r): ?>
<?php
  $estadoOk = (isset($r['checked_in']) && (int)$r['checked_in'] === 1);
  $codigo   
?>
<tr>
  <td><?php echo (int)$r['id']; ?></td>
  <td><?php echo e($r['nombre']); ?></td>
  <td><?php echo e($r['tipo']); ?></td>
  <td>
    <?php if ($estadoOk): ?>
      <span class="badge-ok">Check in OK</span>
    <?php else: ?>
      <span class="badge-pend">Pendiente</span>
    <?php endif; ?>
  </td>
  <td>
    <?php if (!$estadoOk && $codigo !== ''): ?>
      <a class="btn-link btn-checkin" href="checkin.php?c=<?php echo urlencode($codigo); ?>">
        Hacer check in
      </a>
    <?php elseif ($estadoOk): ?>
      <span style="font-size:0.75rem;color:#9f9;">Ya checkeada</span>
    <?php endif; ?>
  </td>
  <td>
    <?php if ($codigo !== ''): ?>
      <a class="btn-link" href="ticket.php?c=<?php echo urlencode($codigo); ?>" target="_blank">
        Ver entrada
      </a>
    <?php endif; ?>
  </td>
  <td>
    <?php if ($codigo !== ''): ?>
      <a class="btn-link" href="email_template.php?c=<?php echo urlencode($codigo); ?>" target="_blank">
        Ver texto
      </a>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; ?>

</tbody>
</table>

</body>
</html>
