<?php
session_start();
date_default_timezone_set('America/Argentina/Buenos_Aires');

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// ===== AUTH =====
if (empty($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
$tipoGlobal = isset($_SESSION['tipo_global']) ? $_SESSION['tipo_global'] : '';
if (!in_array($tipoGlobal, array('admin_evento','super_admin'), true)) {
    header("Location: login.php");
    exit;
}
$adminId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;

// ===== DB =====
$dbFile = __DIR__ . '/save_the_rave.sqlite';
if (!file_exists($dbFile)) {
    http_response_code(500);
    echo "Base no encontrada";
    exit;
}
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $ex) {
    http_response_code(500);
    echo "Error DB: " . e($ex->getMessage());
    exit;
}

// ===== Detectar columnas opcionales =====
$colsEv = $pdo->query("PRAGMA table_info(eventos)")->fetchAll(PDO::FETCH_ASSOC);
$hasCreadoPor = false;
foreach($colsEv as $c){
    if (isset($c['name']) && $c['name']==='creado_por_admin_id') { $hasCreadoPor=true; break; }
}

$colsEnt = $pdo->query("PRAGMA table_info(entradas)")->fetchAll(PDO::FETCH_ASSOC);
$hasEventoIdEntradas = false;
foreach($colsEnt as $c){
    if (isset($c['name']) && $c['name']==='evento_id') { $hasEventoIdEntradas=true; break; }
}

// ===== Buscador de eventos =====
$qev = isset($_GET['qev']) ? trim($_GET['qev']) : '';

// ===== Traer eventos visibles =====
$whereEv = array();
$paramsEv = array();

if ($tipoGlobal === 'admin_evento' && $hasCreadoPor && $adminId>0) {
    $whereEv[] = "creado_por_admin_id = :aid";
    $paramsEv[':aid'] = $adminId;
}

if ($qev !== '') {
    $whereEv[] = "(nombre LIKE :qev OR slug LIKE :qev)";
    $paramsEv[':qev'] = '%'.$qev.'%';
}

$whereEvSql = !empty($whereEv) ? ("WHERE ".implode(" AND ", $whereEv)) : "";

$stmtEv = $pdo->prepare("SELECT * FROM eventos $whereEvSql ORDER BY id DESC");
$stmtEv->execute($paramsEv);
$eventos = $stmtEv->fetchAll(PDO::FETCH_ASSOC);

// ===== Stats globales y por evento =====
$eventoIds = array();
foreach($eventos as $r){
    $eventoIds[] = (int)$r['id'];
}

$statsGlobal = array('total'=>0,'checkins'=>0,'pendientes'=>0);
$statsPorEvento = array();

// Si no hay columna evento_id todavía, contamos todo como global
if (!$hasEventoIdEntradas || empty($eventoIds)) {
    $totalG = (int)$pdo->query("SELECT COUNT(*) FROM entradas")->fetchColumn();
    $checkG = (int)$pdo->query("SELECT COUNT(*) FROM entradas WHERE checked_in=1")->fetchColumn();
    $pendG  = max(0, $totalG-$checkG);
    $statsGlobal = array('total'=>$totalG,'checkins'=>$checkG,'pendientes'=>$pendG);

    foreach($eventoIds as $eid){
        $statsPorEvento[$eid] = array('total'=>0,'checkins'=>0,'pendientes'=>0);
    }
} else {
    // Global SOLO de eventos visibles del admin
    $in = implode(",", array_fill(0,count($eventoIds),'?'));

    $stmtTot = $pdo->prepare("SELECT COUNT(*) FROM entradas WHERE evento_id IN ($in)");
    $stmtTot->execute($eventoIds);
    $totalG = (int)$stmtTot->fetchColumn();

    $stmtChk = $pdo->prepare("SELECT COUNT(*) FROM entradas WHERE checked_in=1 AND evento_id IN ($in)");
    $stmtChk->execute($eventoIds);
    $checkG = (int)$stmtChk->fetchColumn();

    $pendG  = max(0, $totalG-$checkG);
    $statsGlobal = array('total'=>$totalG,'checkins'=>$checkG,'pendientes'=>$pendG);

    // Por evento
    foreach($eventoIds as $eid){
        $stmtE = $pdo->prepare("SELECT COUNT(*) FROM entradas WHERE evento_id=?");
        $stmtE->execute(array($eid));
        $t = (int)$stmtE->fetchColumn();

        $stmtEc = $pdo->prepare("SELECT COUNT(*) FROM entradas WHERE checked_in=1 AND evento_id=?");
        $stmtEc->execute(array($eid));
        $c = (int)$stmtEc->fetchColumn();

        $p = max(0, $t-$c);
        $statsPorEvento[$eid] = array('total'=>$t,'checkins'=>$c,'pendientes'=>$p);
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Panel general – Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root{color-scheme:dark;}
    *{box-sizing:border-box;}
    body{
      margin:0;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      background:#050505;color:#f5f5f5;padding:16px;
    }
    a{color:inherit}

    .topbar{
      display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:14px;
    }
    .topbar .spacer{flex:1 1 auto;}
    .btn-link{
      display:inline-block;padding:6px 10px;border-radius:10px;background:#222;color:#eee;text-decoration:none;
      font-size:.85rem;white-space:nowrap;
    }
    .btn-link:hover{background:#2d2d2d;}
    .btn-primary{background:#d71d24;}
    .btn-primary:hover{filter:brightness(1.05);}

    h1{margin:0 0 6px;font-size:1.45rem;}
    .small{font-size:.85rem;color:#9ca3af;margin-bottom:8px;}

    .stats{display:flex;gap:12px;flex-wrap:wrap;margin-top:6px;margin-bottom:10px;}
    .card{
      background:#141414;border-radius:12px;padding:10px 14px;box-shadow:0 8px 20px rgba(0,0,0,.4);
      min-width:170px;
    }
    .card .label{font-size:.8rem;color:#aaa;}
    .card .value{margin-top:3px;font-size:1.5rem;font-weight:700;}
    .badge-ok{
      display:inline-block;padding:2px 8px;border-radius:999px;background:#124221;color:#a6f3b7;font-size:.75rem;
    }
    .badge-pend{
      display:inline-block;padding:2px 8px;border-radius:999px;background:#402018;color:#ffb39a;font-size:.75rem;
    }

    .filters{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:4px;}
    .filters input{
      padding:7px 9px;border-radius:8px;border:1px solid #333;background:#111;color:#f5f5f5;font-size:.9rem;
      min-width:220px;
    }
    .filters button{
      padding:7px 12px;border-radius:999px;border:none;background:#d71d24;color:#fff;font-weight:600;cursor:pointer;
      font-size:.85rem;
    }

    table{width:100%;border-collapse:collapse;margin-top:12px;font-size:.9rem;}
    th,td{border-bottom:1px solid #333;padding:8px;vertical-align:middle;}
    th{background:#181818;text-align:left;position:sticky;top:0;}
    tr:hover td{background:#111;}

    .flyer-thumb{
      width:74px;height:74px;object-fit:cover;border-radius:8px;border:1px solid #333;background:#000;
    }
    .muted{color:#9ca3af;font-size:.85rem;}
  </style>
</head>
<body>

<div class="topbar">
  <a class="btn-link btn-primary" href="crear_evento.php">Crear evento</a>
  <a class="btn-link" href="secundarios.php">Mi staff</a>
  <a class="btn-link" href="eventos.php">Ver todos los eventos</a>
  <a class="btn-link" href="mi_sitio.php">Mi sitio</a>

  <span class="spacer"></span>

  <a class="btn-link" href="mi_perfil.php">Mi perfil</a>
  <a class="btn-link" href="login.php?logout=1">Salir</a>
</div>

<h1>Panel general</h1>
<div class="small">
  Usuario: <strong><?php echo e($_SESSION['usuario']); ?></strong>
  <?php if($tipoGlobal==='super_admin'): ?> — <span class="badge-ok">SUPER ADMIN</span><?php endif; ?>
</div>

<div class="stats">
  <div class="card">
    <div class="label">Entradas totales (todos mis eventos)</div>
    <div class="value"><?php echo (int)$statsGlobal['total']; ?></div>
  </div>
  <div class="card">
    <div class="label">Check-ins</div>
    <div class="value"><?php echo (int)$statsGlobal['checkins']; ?></div>
  </div>
  <div class="card">
    <div class="label">Pendientes</div>
    <div class="value"><?php echo (int)$statsGlobal['pendientes']; ?></div>
  </div>
</div>

<form method="get" class="filters">
  <input type="text" name="qev" placeholder="Buscar evento por nombre o slug" value="<?php echo e($qev); ?>">
  <button type="submit">Buscar</button>
</form>

<h2 style="margin-top:14px;font-size:1.15rem;">Mis eventos</h2>

<table>
  <thead>
    <tr>
      <th>Flyer</th>
      <th>Evento</th>
      <th>Slug</th>
      <th>Fecha</th>
      <th>Totales</th>
      <th>Check-ins</th>
      <th>Pendientes</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
  <?php if(empty($eventos)): ?>
    <tr><td colspan="8" class="muted">No hay eventos para mostrar.</td></tr>
  <?php else: ?>
    <?php foreach($eventos as $ev): ?>
      <?php
        $eid = (int)$ev['id'];
        $st = isset($statsPorEvento[$eid]) ? $statsPorEvento[$eid] : array('total'=>0,'checkins'=>0,'pendientes'=>0);
        $fd = isset($ev['fecha_desde']) ? $ev['fecha_desde'] : '';
        $fh = isset($ev['fecha_hasta']) ? $ev['fecha_hasta'] : '';
        $flyerOk = (!empty($ev['flyer_filename']) && file_exists(__DIR__ . '/' . $ev['flyer_filename']));
      ?>
      <tr>
        <td>
          <?php if($flyerOk): ?>
            <img src="<?php echo e($ev['flyer_filename']); ?>" class="flyer-thumb" alt="Flyer">
          <?php else: ?>
            <span class="muted">Sin flyer</span>
          <?php endif; ?>
        </td>
        <td><?php echo e($ev['nombre']); ?></td>
        <td><?php echo e($ev['slug']); ?></td>
        <td>
          <?php
            if($fd==='' && $fh==='') echo '<span class="muted">Sin fecha</span>';
            else {
              echo e($fd);
              if($fh!=='') echo ' → '.e($fh);
            }
          ?>
        </td>
        <td><?php echo (int)$st['total']; ?></td>
        <td><?php echo (int)$st['checkins']; ?></td>
        <td>
          <?php if((int)$st['pendientes']>0): ?>
            <span class="badge-pend"><?php echo (int)$st['pendientes']; ?> pendientes</span>
          <?php else: ?>
            <span class="badge-ok">0 pendientes</span>
          <?php endif; ?>
        </td>
        <td>
          <a class="btn-link" href="panel_evento.php?id=<?php echo $eid; ?>">Administrar</a>
          <a class="btn-link" href="editar_evento.php?id=<?php echo $eid; ?>">Editar</a>
        </td>
      </tr>
    <?php endforeach; ?>
  <?php endif; ?>
  </tbody>
</table>

</body>
</html>
