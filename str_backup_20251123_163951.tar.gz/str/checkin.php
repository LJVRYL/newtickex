<?php
// checkin.php – marca la entrada como chequeada y muestra un QR
date_default_timezone_set('America/Argentina/Buenos_Aires');

$dbFile = __DIR__ . '/save_the_rave.sqlite';
if (!file_exists($dbFile)) {
    die('Base de datos no encontrada.');
}

$codigo = isset($_GET['c']) ? trim($_GET['c']) : '';

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $entrada = null;
    if ($codigo !== '') {
        $stmt = $pdo->prepare('SELECT id, nombre, email, fecha_registro, codigo, checked_in, checked_in_at FROM entradas WHERE codigo = :codigo');
        $stmt->execute([':codigo' => $codigo]);
        $entrada = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if ($entrada) {
        // Si todavía no estaba chequeada, la marcamos ahora
        if ((int)$entrada['checked_in'] === 0) {
            $ahora = date('Y-m-d H:i:s');
            $upd = $pdo->prepare('UPDATE entradas SET checked_in = 1, checked_in_at = :fecha WHERE id = :id');
            $upd->execute([
                ':fecha' => $ahora,
                ':id'    => $entrada['id'],
            ]);
            $entrada['checked_in']    = 1;
            $entrada['checked_in_at'] = $ahora;
        }
    }

} catch (Exception $e) {
    die('Error al leer la base: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}

$baseUrl    = 'https://str.tickex.com.ar';
$checkinUrl = $baseUrl . '/checkin.php?c=' . urlencode($codigo);
$qrUrl      = 'https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=' . urlencode($checkinUrl);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Save The Rave – Check-in</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #000;
      color: #f5f5f5;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .card {
      width: 100%;
      max-width: 420px;
      background: #111;
      border-radius: 16px;
      padding: 20px 22px;
      box-shadow: 0 18px 36px rgba(0,0,0,0.6);
      text-align: center;
    }
    h1 {
      font-size: 1.4rem;
      margin-bottom: 12px;
    }
    .status {
      display: inline-block;
      margin: 10px 0 16px;
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      font-weight: 600;
    }
    .status-ok {
      background: #234326;
      color: #8df09e;
    }
    .status-error {
      background: #442222;
      color: #ff9b9b;
    }
    .info {
      font-size: 0.9rem;
      margin-bottom: 12px;
    }
    .info small {
      display: block;
      font-size: 0.75rem;
      color: #aaa;
    }
    .qr {
      margin-top: 10px;
      margin-bottom: 12px;
    }
    .qr img {
      max-width: 100%;
      height: auto;
      border-radius: 8px;
      background: #fff;
      padding: 6px;
    }
    .link {
      font-size: 0.75rem;
      word-break: break-all;
      color: #ccc;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Save The Rave – Entrada</h1>

    <?php if (!$entrada): ?>
      <div class="status status-error">Código no válido</div>
      <p class="info">No encontramos una entrada para este código.</p>
    <?php else: ?>
      <?php if ((int)$entrada['checked_in'] === 1): ?>
        <div class="status status-ok">Entrada chequeada</div>
      <?php else: ?>
        <div class="status status-error">Pendiente</div>
      <?php endif; ?>

      <p class="info">
        #<?php echo (int)$entrada['id']; ?> –
        <?php echo htmlspecialchars($entrada['nombre'], ENT_QUOTES, 'UTF-8'); ?>
        <small><?php echo htmlspecialchars($entrada['email'], ENT_QUOTES, 'UTF-8'); ?></small>
      </p>

      <div class="qr">
        <img
          src="<?php echo htmlspecialchars($qrUrl, ENT_QUOTES, 'UTF-8'); ?>"
          alt="QR de entrada"
        />
      </div>

      <p class="link">
        Link de esta entrada:<br>
        <?php echo htmlspecialchars($checkinUrl, ENT_QUOTES, 'UTF-8'); ?>
      </p>

      <?php if (!empty($entrada['checked_in_at'])): ?>
        <p class="info">
          <small>Chequeada el: <?php echo htmlspecialchars($entrada['checked_in_at'], ENT_QUOTES, 'UTF-8'); ?></small>
        </p>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</body>
</html>
