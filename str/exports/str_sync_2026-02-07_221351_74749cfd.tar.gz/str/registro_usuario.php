<?php
// registro_usuario.php – Paso 1: pedir solo email y enviar link con token

require_once __DIR__.'/inc/bootstrap.php';

$title     = 'Registro – Paso 1';
$errores   = array();
$mensajeOk = '';
$email     = '';

// ---------- función para enviar el mail con el link ----------
function enviar_mail_confirmacion_step1($email, $token)
{
    $fromEmail = 'no-reply@tickex.com.ar';
    $fromName  = 'Tickex';
    $from      = $fromName . ' <' . $fromEmail . '>';

    $link    = 'https://str.tickex.com.ar/completar_registro.php?token=' . urlencode($token);
    $subject = 'Confirmá tu email en Tickex';

    $body  = "Hola,\n\n";
    $body .= "Para continuar tu registro en Tickex, hacé clic en este enlace:\n";
    $body .= $link . "\n\n";
    $body .= "Si no fuiste vos, podés ignorar este mensaje.\n\n";
    $body .= "Tickex\n";

    $headers  = "From: " . $from . "\r\n";
    $headers .= "Reply-To: " . $fromEmail . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

    // Envelope sender (-f) importante
    $extraParams = '-f ' . $fromEmail;

    $ok = mail($email, $subject, $body, $headers, $extraParams);

    // Log simple
    $logLine = date('c') . " registro_step1 mail to=" . $email . " ok=" . ($ok ? '1' : '0') . "\n";
    @file_put_contents(__DIR__ . '/log_mail_registro.txt', $logLine, FILE_APPEND);

    return $ok;
}

// ---------- POST: procesar email ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    if ($email === '') {
        $errores[] = 'El email es obligatorio.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = 'El email no tiene un formato válido.';
    }

    if (empty($errores)) {
        try {
            $pdo = db();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // ¿Ya existe ese email?
            $st = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email LIMIT 1");
            $st->execute(array(':email' => $email));
            $u = $st->fetch(PDO::FETCH_ASSOC);

            if ($u && isset($u['email_confirmado']) && (int)$u['email_confirmado'] === 1) {
                // Ya confirmado
                $mensajeOk = 'Ese email ya está registrado y confirmado. Podés usarlo para iniciar sesión.';
            } else {
                // Generar token
                if (function_exists('random_bytes')) {
                    $token = bin2hex(random_bytes(16));
                } else {
                    $token = sha1(uniqid(mt_rand(), true));
                }

                $ahora = date('Y-m-d H:i:s');

                if ($u) {
                    // Usuario existente sin confirmar: actualizar token
                    $stmtUp = $pdo->prepare("
                        UPDATE usuarios
                        SET token_confirmacion = :token,
                            email_confirmado   = 0
                        WHERE id = :id
                    ");
                    $stmtUp->execute(array(
                        ':token' => $token,
                        ':id'    => (int)$u['id'],
                    ));
                } else {
                    // Usuario nuevo: crear registro mínimo
                    $stmtIns = $pdo->prepare("
                        INSERT INTO usuarios
                            (nombre, apellido, email, dni, password_hash, rol, email_confirmado, token_confirmacion, creado_en)
                        VALUES
                            ('', '', :email, '', '', 'cliente', 0, :token, :creado_en)
                    ");
                    $stmtIns->execute(array(
                        ':email'     => $email,
                        ':token'     => $token,
                        ':creado_en' => $ahora,
                    ));
                }

                $mailOk = enviar_mail_confirmacion_step1($email, $token);

                $mensajeOk  = 'Te enviamos un mensaje a ';
                $mensajeOk .= htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
  

                if (!$mailOk) {
                    $mensajeOk .= ' (Aviso: mail() devolvió false, revisar configuración de correo.)';
                }

                // Limpiar el campo para que no quede el email en el form
                $email = '';
            }
        } catch (Exception $e) {
            $errores[] = 'Error al procesar el registro: ' . $e->getMessage();
        }
    }
}

include __DIR__.'/inc/layout_top.php';
?>
<div class="card" style="max-width:480px;margin:0 auto 16px auto;text-align:center;">
  <div style="margin-bottom:16px;">
    <img src="tickex-logo_sobre_oscuro.svg"
         alt="Tickex"
         style="height:230px;display:block;margin:0 auto 8px auto;">
  </div>
  <h2>Registrate en Tickex</h2>
  <p style="color:var(--muted);margin-top:8px;">
    Ingresá tu email para recibir un enlace y completar tu registro.
  </p>
</div>

<?php if (!empty($errores)): ?>
  <div class="card" style="max-width:480px;margin:0 auto 16px auto;">
    <div class="flash err">
      <ul style="margin:0 0 0 18px;padding:0;">
        <?php foreach ($errores as $e): ?>
          <li><?php echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8'); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<?php if ($mensajeOk !== ''): ?>
  <div class="card" style="max-width:480px;margin:0 auto 16px auto;">
    <div class="flash ok">
      <strong>Revisá tu email</strong><br><br>
      <?php echo $mensajeOk; ?><br><br>
      Si no ves el mail en unos minutos, revisá la carpeta de spam / correo no deseado.
    </div>
  </div>
<?php endif; ?>

<div class="card" style="max-width:480px;margin:0 auto 32px auto;">
  <form method="post" autocomplete="off">
    <label for="email" style="margin-top:8px;display:block;">Email</label>
    <input type="email" id="email" name="email" required
           value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>">

    <button class="btn" type="submit" style="width:100%;margin-top:16px;">
      Enviarme enlace de registro
    </button>
  </form>
</div>

<?php include __DIR__.'/inc/layout_bottom.php'; ?>
