// assets/str.js
