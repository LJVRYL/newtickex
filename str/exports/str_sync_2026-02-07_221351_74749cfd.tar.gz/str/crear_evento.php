<?php
require_once __DIR__.'/inc/bootstrap.php';
$title = "Crear evento – TICKEX";

// Sólo super_admin o admin_evento pueden crear eventos
require_login();

$cu = current_user();
$tipoGlobal = isset($_SESSION['tipo_global'])
    ? $_SESSION['tipo_global']
    : (isset($cu['rol']) ? $cu['rol'] : '');

if (!in_array($tipoGlobal, array('super_admin','admin_evento','superadmin'), true)) {
    header('Location: panel_admin.php');
    exit;
}

$adminId = isset($_SESSION['user_id'])
    ? (int)$_SESSION['user_id']
    : (isset($cu['id']) ? (int)$cu['id'] : 0);

try {
    $pdo = db();
} catch (Exception $e) {
    http_response_code(500);
    echo "Error DB: " . e($e->getMessage());
    exit;
}

// Detectar si existe creado_por_admin_id en eventos
$colsEv = $pdo->query("PRAGMA table_info(eventos)")->fetchAll(PDO::FETCH_ASSOC);
$hasCreadoPor = false;
foreach ($colsEv as $c) {
    if (isset($c['name']) && $c['name'] === 'creado_por_admin_id') {
        $hasCreadoPor = true;
        break;
    }
}

// Valores por defecto para repintar form
$nombre      = '';
$slug        = '';
$fechaDesde  = '';
$fechaHasta  = '';
$descripcion = '';

// flash messages
$flashes = function_exists('flash_get_all') ? flash_get_all() : array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nombre      = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $slug        = isset($_POST['slug']) ? trim($_POST['slug']) : '';
    $fechaDesde  = isset($_POST['fecha_desde']) ? trim($_POST['fecha_desde']) : '';
    $fechaHasta  = isset($_POST['fecha_hasta']) ? trim($_POST['fecha_hasta']) : '';
    $descripcion = isset($_POST['descripcion']) ? trim($_POST['descripcion']) : '';

    $errorMsg = '';

    // Validaciones básicas
    if ($nombre === '' || $slug === '') {
        $errorMsg = 'Nombre y slug son obligatorios.';
    } elseif (!preg_match('/^[a-z0-9\-]+$/', $slug)) {
        $errorMsg = 'El slug solo puede tener minúsculas, números y guiones (a-z, 0-9, -).';
    } else {
        // Unicidad de slug
        $stSlug = $pdo->prepare("SELECT id FROM eventos WHERE slug = :slug LIMIT 1");
        $stSlug->execute(array(':slug'=>$slug));
        $slugRow = $stSlug->fetch(PDO::FETCH_ASSOC);
        if ($slugRow) {
            $errorMsg = 'Ese slug ya está en uso por otro evento.';
        }
    }

    // Manejar flyer (opcional)
    $flyerFilename = null;
    if ($errorMsg === '') {
        if (isset($_FILES['flyer']) && $_FILES['flyer']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['flyer']['error'] === UPLOAD_ERR_OK) {
                $tmp  = $_FILES['flyer']['tmp_name'];
                $size = (int)$_FILES['flyer']['size'];

                if ($size > 2 * 1024 * 1024) {
                    $errorMsg = "El flyer no puede pesar más de 2 MB.";
                } else {
                    $ext = strtolower(pathinfo($_FILES['flyer']['name'], PATHINFO_EXTENSION));
                    if (!in_array($ext, array('png','jpg','jpeg'), true)) {
                        $errorMsg = "Solo se permiten imágenes PNG o JPG.";
                    } else {
                        $safe = preg_replace('/[^a-zA-Z0-9_\-\.]/','_', $_FILES['flyer']['name']);
                        $new  = time() . '_' . $safe;
                        $dest = __DIR__ . '/event_flyers/' . $new;
                        if (!move_uploaded_file($tmp, $dest)) {
                            $errorMsg = "No se pudo guardar el flyer en el servidor.";
                        } else {
                            $flyerFilename = 'event_flyers/' . $new;
                        }
                    }
                }
            } else {
                $errorMsg = "Error al subir el flyer (código: " . (int)$_FILES['flyer']['error'] . ").";
            }
        }
    }

    if ($errorMsg !== '') {
        flash('err', $errorMsg);
    } else {
        try {
            $pdo->beginTransaction();

            if ($hasCreadoPor) {
                $stmtEv = $pdo->prepare("
                    INSERT INTO eventos
                        (nombre, slug, descripcion, flyer_filename, fecha_desde, fecha_hasta, creado_en, creado_por_admin_id)
                    VALUES
                        (:nombre, :slug, :descripcion, :flyer, :fdesde, :fhasta, datetime('now'), :creador)
                ");
                $stmtEv->execute(array(
                    ':nombre'      => $nombre,
                    ':slug'        => $slug,
                    ':descripcion' => ($descripcion !== '' ? $descripcion : null),
                    ':flyer'       => $flyerFilename,
                    ':fdesde'      => ($fechaDesde !== '' ? $fechaDesde : null),
                    ':fhasta'      => ($fechaHasta !== '' ? $fechaHasta : null),
                    ':creador'     => $adminId,
                ));
            } else {
                $stmtEv = $pdo->prepare("
                    INSERT INTO eventos
                        (nombre, slug, descripcion, flyer_filename, fecha_desde, fecha_hasta, creado_en)
                    VALUES
                        (:nombre, :slug, :descripcion, :flyer, :fdesde, :fhasta, datetime('now'))
                ");
                $stmtEv->execute(array(
                    ':nombre'      => $nombre,
                    ':slug'        => $slug,
                    ':descripcion' => ($descripcion !== '' ? $descripcion : null),
                    ':flyer'       => $flyerFilename,
                    ':fdesde'      => ($fechaDesde !== '' ? $fechaDesde : null),
                    ':fhasta'      => ($fechaHasta !== '' ? $fechaHasta : null),
                ));
            }

            $eventoId = (int)$pdo->lastInsertId();
            $pdo->commit();

            // Nuevo flujo: ir a configurar_entradas_evento.php
            header('Location: configurar_entradas_evento.php?id=' . $eventoId);
            exit;

                } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
                        $msg = $e->getMessage();
                        if (stripos($msg, 'unique') !== false && stripos($msg, 'slug') !== false) {
                                $msg = 'Ese slug ya está en uso por otro evento.';
                        }
                        flash('err', 'Error al crear el evento: ' . $msg);
        }
    }
}

include __DIR__.'/inc/layout_top.php';
?>
<?php if (!empty($flashes)): ?>
    <div class="card" style="max-width:640px;margin:0 auto 12px auto;">
        <?php foreach ($flashes as $f): ?>
            <div class="flash <?php echo e($f['type']); ?>"><?php echo e($f['msg']); ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<div class="card" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
  <a class="btn secondary" href="panel_admin.php">⬅ Volver al panel</a>
  <?php if ($tipoGlobal === 'super_admin' || $tipoGlobal === 'superadmin'): ?>
    <a class="btn secondary" href="superadmin.php">SuperAdmin</a>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Crear nuevo evento</h2>
  <div style="color:var(--muted);font-size:14px;">
    Usuario: <strong><?php echo e(isset($_SESSION['usuario']) ? $_SESSION['usuario'] : ''); ?></strong>
    (<?php echo e($tipoGlobal); ?>)<br>
    Esta pantalla crea el evento. Después vas a configurar las entradas
    en el siguiente paso.
  </div>
</div>

<form method="post" enctype="multipart/form-data">

  <div class="card">
    <h3>Datos del evento</h3>

    <label for="nombre">Nombre del evento</label>
    <input type="text" id="nombre" name="nombre" required value="<?php echo e($nombre); ?>">

    <label for="slug">Slug / URL corta (ej: &quot;str2&quot;, &quot;retro&quot;)</label>
    <input type="text" id="slug" name="slug" required
           placeholder="solo minúsculas, números y -" value="<?php echo e($slug); ?>">

    <label for="descripcion">Descripción breve (opcional)</label>
    <textarea id="descripcion" name="descripcion"
              placeholder="Texto descriptivo del evento..."><?php echo e($descripcion); ?></textarea>

    <label>Fechas del evento (desde / hasta)</label>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <div style="flex:1 1 140px;">
        <label for="fecha_desde">Desde</label>
        <input type="date" id="fecha_desde" name="fecha_desde" value="<?php echo e($fechaDesde); ?>">
      </div>
      <div style="flex:1 1 140px;">
        <label for="fecha_hasta">Hasta</label>
        <input type="date" id="fecha_hasta" name="fecha_hasta" value="<?php echo e($fechaHasta); ?>">
      </div>
    </div>

    <label for="flyer">Flyer del evento (PNG/JPG, máx. 2MB)</label>
    <input type="file" id="flyer" name="flyer" accept="image/png,image/jpeg">
  </div>

  <button class="btn" type="submit">Crear evento y configurar entradas</button>
</form>

<?php include __DIR__.'/inc/layout_bottom.php'; ?>
