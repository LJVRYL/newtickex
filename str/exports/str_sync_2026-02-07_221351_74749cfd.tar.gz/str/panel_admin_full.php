<?php
// panel_admin_full.php - Panel general "gordo" experimental

require_once __DIR__ . '/inc/bootstrap.php';

// Título para layout_top.php (si lo usás después)
$title = 'Panel general – TICKEX';

// Aseguramos login usando los helpers nuevos
require_login();
$cu = current_user();

// Resolver usuario de sesión:
// 1) Si ya tenemos $_SESSION['usuario'] lo usamos.
// 2) Si venimos del login viejo (admin.php) con is_admin = true, asumimos AdminSTR.
$sessionUser = null;
if (!empty($_SESSION['usuario'])) {
    $sessionUser = $_SESSION['usuario'];
} elseif (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) {
    $sessionUser = 'AdminSTR';
}

// Si no hay usuario logueado de ninguna forma, mandamos a login_admin
if ($sessionUser === null) {
    header('Location: login_admin.php');
    exit;
}

// Conexión a DB usando helper db() (PHP5-safe)
try {
    $pdo = db();
} catch (Exception $e) {
    http_response_code(500);
    echo "Error DB: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    exit;
}

// Usuario actual (tabla usuarios_admin)
$stmtUser = $pdo->prepare("
    SELECT id, username, tipo_global, nombre
    FROM usuarios_admin
    WHERE username = :u
    LIMIT 1
");
$stmtUser->execute(array(':u' => $sessionUser));
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    http_response_code(403);
    echo "Usuario no encontrado.";
    exit;
}

if (!function_exists('e')) {
    function e($s) {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    }
}

// === Contadores globales de entradas (por ahora todas) ===
$total    = 0;
$checkins = 0;
$faltan   = 0;

try {
    $total    = (int)$pdo->query("SELECT COUNT(*) FROM entradas")->fetchColumn();
    // OJO: aquí se asume columna checked_in = 1. Si tu schema usa 'checkin IS NOT NULL',
    // cambiá esta línea por: WHERE checkin IS NOT NULL
    $checkins = (int)$pdo->query("SELECT COUNT(*) FROM entradas WHERE checked_in = 1")->fetchColumn();
    $faltan   = max(0, $total - $checkins);
} catch (Exception $e) {
    // Si algo falla, dejamos 0/0/0 sin romper la página
}

// === Listado de eventos (por ahora todos; más adelante se filtra por dueño) ===
$stmtEv = $pdo->query("
    SELECT id, nombre, slug, flyer_filename, fecha_desde, fecha_hasta
    FROM eventos
    ORDER BY id ASC
");
$eventos = $stmtEv->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Panel general – TICKEX</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root { color-scheme: dark; }
    * { box-sizing:border-box; }
    body {
      margin:0;
      padding:16px;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background:#020617;
      color:#e5e7eb;
    }
    h1 {
      margin:0 0 6px;
      font-size:1.4rem;
    }
    .sub {
      font-size:0.85rem;
      color:#9ca3af;
      margin-bottom:14px;
    }
    .top-bar {
      display:flex;
      justify-content:space-between;
      align-items:flex-start;
      gap:12px;
      flex-wrap:wrap;
      margin-bottom:14px;
    }
    .btn-link {
      display:inline-block;
      padding:6px 10px;
      border-radius:999px;
      background:#111827;
      color:#e5e7eb;
      text-decoration:none;
      font-size:0.8rem;
      margin-right:8px;
      border:1px solid #1f2937;
    }
    .btn-link:hover { background:#1f2937; }
    .cards {
      display:flex;
      flex-wrap:wrap;
      gap:12px;
      margin-bottom:16px;
    }
    .card {
      background:#020617;
      border-radius:14px;
      padding:12px 14px;
      border:1px solid #1f2937;
      box-shadow:0 10px 25px rgba(0,0,0,0.5);
      flex:1 1 200px;
      min-width:180px;
    }
    .card-label {
      font-size:0.8rem;
      color:#9ca3af;
      margin-bottom:2px;
    }
    .card-value {
      font-size:1.5rem;
      font-weight:700;
      margin-bottom:2px;
    }
    .card-de
      font-size:0.78rem;
      color:#6b7280;
    }
    h2 {
      margin:10px 0 6px;
    
    }
    table {
      width:100%;
      border-collapse:collapse;
      margin-top:6px;
      font-size:0.85rem;
    }
    th, td {
      padding:6px 8px;
      border-bottom:1px solid #1f2937;
      vertical-align:middle;
    }
    th {
      background:#111827;
      text-align:left;
    }
    tr:hover td {
      background:#020617;
    }
    img.flyer-thumb {
      max-width:70px;
      border:1px solid #1f2937;
    }
    .badge-date {
      font-size:0.75rem;
      color:#9ca3af;
    }
  </style>
</head>
<body>

<div class="top-bar">
  <div>
    <h1>Panel general</h1>
    <div class="sub">
      Usuario:
      <strong>
        <?php
          $nombreMostrar = 'admin';
          if (!empty($user['nombre'])) {
              $nombreMostrar = $user['nombre'];
          } elseif (!empty($user['username'])) {
              $nombreMostrar = $user['username'];
          }
          echo e($nombreMostrar);
        ?>
      </strong>
      (<?php echo e($user['tipo_global']); ?>)
    </div>
  </div>
  <div>
    <a class="btn-link" href="panel_admin.php">Panel clásico (lista STR)</a>
    <a class="btn-link" href="mi_perfil.php">Mi perfil</a>
    <a class="btn-link" href="crear_evento.php">Crear evento</a>
    <a class="btn-link" href="secundarios.php">Administradores secundarios</a>
    <a class="btn-link" href="eventos.php">Ver todos los eventos</a>
    <?php if ($user['tipo_global'] === 'super_admin'): ?>
      <a class="btn-link" href="superadmin.php">SuperAdmin</a>
    <?php endif; ?>
  </div>
</div>

<div class="cards">
  <div class="card">
    <div class="card-label">Entradas totales (todos los eventos)</div>
    <div class="card-value"><?php echo (int)$total; ?></div>
    <div class="card-desc">Suma de todas las entradas registradas en esta base.</div>
  </div>
  <div class="card">
    <div class="card-label">Check-ins realizados</div>
    <div class="card-value"><?php echo (int)$checkins; ?></div>
    <div class="card-desc">Entradas marcadas como utilizadas.</div>
  </div>
  <div class="card">
    <div class="card-label">Faltan por escanear</div>
    <div class="card-value"><?php echo (int)$faltan; ?></div>
    <div class="card-desc">Entradas pendientes de ingreso.</div>
  </div>
</div>

<h2>Mis eventos</h2>
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Flyer</th>
      <th>Nombre</th>
      <th>Slug</th>
      <th>Fecha(s)</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php if (!$eventos): ?>
      <tr>
        <td colspan="6" style="font-size:0.8rem;color:#9ca3af;">
          Todavía no tenés eventos creados.
        </td>
      </tr>
    <?php else: ?>
      <?php foreach ($eventos as $ev): ?>
        <tr>
          <td><?php echo (int)$ev['id']; ?></td>
          <td>
            <?php if (!empty($ev['flyer_filename']) && file_exists(__DIR__ . '/' . $ev['flyer_filename'])): ?>
              <img src="<?php echo e($ev['flyer_filename']); ?>" alt="Flyer" class="flyer-thumb">
            <?php else: ?>
              <span style="font-size:0.75rem;color:#6b7280;">Sin flyer</span>
            <?php endif; ?>
          </td>
          <td><?php echo e($ev['nombre']); ?></td>
          <td><?php echo e($ev['slug']); ?></td>
          <td class="badge-date">
            <?php
              $fd = isset($ev['fecha_desde']) ? $ev['fecha_desde'] : '';
              $fh = isset($ev['fecha_hasta']) ? $ev['fecha_hasta'] : '';
              if ($fd === '' && $fh === '') {
                  echo 'Sin fechas';
              } else {
                  echo e($fd);
                  if ($fh !== '') {
                      echo ' → ' . e($fh);
                  }
              }
            ?>
          </td>
          <td>
            <a class="btn-link" href="panel_evento.php?id=<?php echo (int)$ev['id']; ?>">Panel del evento</a>
            <a class="btn-link" href="editar_evento.php?id=<?php echo (int)$ev['id']; ?>">Editar</a>
          </td>
        </tr>
      <?php endforeach; ?>
    <?php endif; ?>
  </tbody>
</table>

</body>
</html>
