<?php
require_once __DIR__ . '/inc/bootstrap.php';
$title = "Mis Entradas";

require_login();
$pdo = db();

// fallback por si alguna página no define e()
if (!function_exists('e')) {
    function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

$tipoGlobal = isset($_SESSION['tipo_global']) ? $_SESSION['tipo_global'] : '';
$adminId    = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;

if (!in_array($tipoGlobal, array('admin_evento','super_admin','superadmin'), true)) {
    abort_404("No tenés permiso.");
}

// Verificar que exista la tabla plantillas_entrada
$hasTablaPlantillas = false;
$error = '';
$okMsg = '';
$chkTpl = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='plantillas_entrada' LIMIT 1");
if ($chkTpl && $chkTpl->fetch(PDO::FETCH_ASSOC)) {
  $hasTablaPlantillas = true;
}

if (!$hasTablaPlantillas) {
  include __DIR__.'/inc/layout_top.php';
  echo "<div class='card'><h2>Plantillas no disponibles</h2><p>No existe la tabla <code>plantillas_entrada</code> en esta base. Creala o importá el esquema para usar Mis Entradas.</p></div>";
  include __DIR__.'/inc/layout_bottom.php';
  exit;
}

/* ========= BASE ========= */
$catFijas = array('Staff','Invitados','Generales','Prensa','Sponsors','Revendedores');
$tiposAll = array('FREE','PAGA','PREPAGA','PUERTA');

function normalizar_cat($c){
    $c = trim($c);
    if ($c==='') return '';
    return ucfirst(strtolower($c));
}

function validar_categoria_tipo($categoria, $tipo){
    $cat = strtolower($categoria);
    $t   = strtoupper($tipo);

    if ($cat==='staff'    && $t!=='FREE')  return "Staff solo permite FREE.";
    if ($cat==='prensa'   && $t!=='FREE')  return "Prensa solo permite FREE.";
    if ($cat==='generales'&& $t==='FREE')  return "Generales no permite FREE.";
    if ($cat==='sponsors' && $t==='PUERTA')return "Sponsors no permite PUERTA.";
    return "";
}

/* ========= ELIMINAR PLANTILLA ========= */
if (isset($_GET['del_id'])) {
  if ($hasTablaPlantillas && isset($_GET['del_id'])) {
    $delId = (int)$_GET['del_id'];

    $st = $pdo->prepare("SELECT id, admin_id, creado_por_admin_id FROM plantillas_entrada WHERE id=?");
    $st->execute(array($delId));
    $row = $st->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        abort_404("Plantilla inexistente.");
    }

    $creador = isset($row['creado_por_admin_id']) && $row['creado_por_admin_id']!==null
        ? (int)$row['creado_por_admin_id']
        : (int)$row['admin_id'];

    if ($tipoGlobal!=='super_admin' && $creador!==$adminId) {
        abort_404("No podés borrar esta plantilla.");
    }

    $pdo->prepare("DELETE FROM plantillas_entrada WHERE id=?")->execute(array($delId));
    header("Location: plantillas_entrada.php");
    exit;
}

/* ========= MODO EDICIÓN ========= */
$editId  = isset($_GET['edit_id']) ? (int)$_GET['edit_id'] : 0;
$editing = false;
$editRow = null;

if ($hasTablaPlantillas && $editId>0) {
    $st = $pdo->prepare("SELECT * FROM plantillas_entrada WHERE id=?");
    $st->execute(array($editId));
    $editRow = $st->fetch(PDO::FETCH_ASSOC);

    if (!$editRow) {
        abort_404("Plantilla inexistente.");
    }

    $creador = isset($editRow['creado_por_admin_id']) && $editRow['creado_por_admin_id']!==null
        ? (int)$editRow['creado_por_admin_id']
        : (int)$editRow['admin_id'];

    if ($tipoGlobal!=='super_admin' && $creador!==$adminId) {
        abort_404("No podés editar esta plantilla.");
    }

    $editing = true;
}

/* ========= CREAR / EDITAR ========= */
$error = '';
$okMsg = '';

if ($hasTablaPlantillas && $_SERVER['REQUEST_METHOD']==='POST') {

    $nombre    = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $categoria = isset($_POST['categoria']) ? trim($_POST['categoria']) : '';
    $catNueva  = isset($_POST['categoria_nueva']) ? trim($_POST['categoria_nueva']) : '';

    if ($categoria==='__new__') {
        $categoria = $catNueva;
    }
    $categoria = normalizar_cat($categoria);

    $tipo       = isset($_POST['tipo']) ? strtoupper(trim($_POST['tipo'])) : 'FREE';
    $precio     = isset($_POST['precio']) ? (int)$_POST['precio'] : 0;
    $cantidad   = isset($_POST['cantidad']) ? (int)$_POST['cantidad'] : 0;
    $hora       = isset($_POST['hora_limite']) ? trim($_POST['hora_limite']) : '';
    $descripcion= isset($_POST['descripcion']) ? trim($_POST['descripcion']) : '';
    $activo     = isset($_POST['activo']) ? 1 : 0;

    if ($nombre==='') $error = "El nombre es obligatorio.";
    if (!$error && $categoria==='') $error = "La categoría es obligatoria.";
    if (!$error && !in_array($tipo, $tiposAll, true)) $error = "Tipo inválido.";
    if (!$error && $precio<0) $error = "Precio inválido.";

    if (!$error && $hora!=='' ) {
        if (!preg_match('/^\d{2}:\d{2}$/', $hora)) {
            $error = "Hora inválida (HH:MM).";
        }
    }

    if (!$error) {
        $msgRule = validar_categoria_tipo($categoria, $tipo);
        if ($msgRule!=='') $error = $msgRule;
    }

    if (!$error && $tipo==='FREE') {
        $precio = 0;
    }

    if (!$error) {
        if ($editing) {
            $st = $pdo->prepare("
                UPDATE plantillas_entrada
                SET categoria=:c, nombre=:n, tipo=:t,
                    precio_default=:p, cantidad_default=:q,
                    hora_limite_default=:h, descripcion=:d, activo=:a
                WHERE id=:id
            ");
            $st->execute(array(
                ':c'=>$categoria, ':n'=>$nombre, ':t'=>$tipo,
                ':p'=>$precio, ':q'=>$cantidad,
                ':h'=>($hora!=='' ? $hora : null),
                ':d'=>($descripcion!=='' ? $descripcion : null),
                ':a'=>$activo,
                ':id'=>$editId
            ));
            $okMsg   = "Plantilla actualizada.";
            $editing = false;
            $editId  = 0;
            $editRow = null;
        } else {
            $st = $pdo->prepare("
                INSERT INTO plantillas_entrada
                (admin_id, creado_por_admin_id, categoria, nombre, tipo,
                 precio_default, cantidad_default, hora_limite_default, descripcion, activo)
                VALUES
                (:aid, :aid, :c, :n, :t, :p, :q, :h, :d, :a)
            ");
            $st->execute(array(
                ':aid'=>$adminId,
                ':c'=>$categoria, ':n'=>$nombre, ':t'=>$tipo,
                ':p'=>$precio, ':q'=>$cantidad,
                ':h'=>($hora!=='' ? $hora : null),
                ':d'=>($descripcion!=='' ? $descripcion : null),
                ':a'=>$activo
            ));
            $okMsg = "Plantilla creada.";
        }
    }
}

/* ========= CATEGORÍAS DISPONIBLES ========= */
$params = array();
$sql = "SELECT DISTINCT categoria FROM plantillas_entrada ";
if ($tipoGlobal!=='super_admin') {
    $sql .= "WHERE creado_por_admin_id=? ";
    $params[] = $adminId;
}
$sql .= "ORDER BY categoria ASC";

$st = $pdo->prepare($sql);
$st->execute($params);
$catsCustom = $st->fetchAll(PDO::FETCH_COLUMN);

$catsDisponibles = $catFijas;
foreach($catsCustom as $cc){
    if ($cc && !in_array($cc, $catsDisponibles, true)) {
        $catsDisponibles[] = $cc;
    }
}

/* ========= LISTAR PLANTILLAS ========= */
$params = array();
$sql = "SELECT * FROM plantillas_entrada ";
if ($tipoGlobal!=='super_admin') {
    $sql .= "WHERE creado_por_admin_id=? ";
    $params[] = $adminId;
}
$sql .= "ORDER BY categoria ASC, nombre ASC, id DESC";

$st = $pdo->prepare($sql);
$st->execute($params);
$plantillas = $st->fetchAll(PDO::FETCH_ASSOC);

/* ========= DEFAULTS FORM ========= */
$formNombre = $editing ? $editRow['nombre'] : '';
$formCat    = $editing ? $editRow['categoria'] : '';
$formTipo   = $editing ? $editRow['tipo'] : 'FREE';
$formPrecio = $editing ? (int)$editRow['precio_default'] : 0;
$formCant   = $editing ? (int)$editRow['cantidad_default'] : 0;
$formHora   = $editing ? $editRow['hora_limite_default'] : '';
$formDesc   = $editing ? $editRow['descripcion'] : '';
$formAct    = $editing ? ((int)$editRow['activo']===1) : true;

include __DIR__.'/inc/layout_top.php';
?>

<div class="card" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
  <a class="btn secondary" href="panel_admin.php">⬅ Volver al panel</a>
  <span style="flex:1 1 auto;"></span>
  <a class="btn danger" href="login.php?logout=1">Salir</a>
</div>

<div class="card">
  <h2>Mis Entradas</h2>
  <div class="muted">Estas plantillas son tuyas y las podés reutilizar en todos tus eventos.</div>

  <?php if ($error): ?>
    <div class="flash err"><?php echo e($error); ?></div>
  <?php endif; ?>

  <?php if ($okMsg): ?>
    <div class="flash ok"><?php echo e($okMsg); ?></div>
  <?php endif; ?>

  <form method="post" style="margin-top:10px;display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;gap:8px;align-items:end;">
    <div>
      <label>Nombre</label>
      <input name="nombre" required value="<?php echo e($formNombre); ?>">
    </div>

    <div>
      <label>Categoría</label>
      <select name="categoria" id="categoriaSelect" required>
        <option value="">Elegí...</option>
        <?php foreach($catsDisponibles as $c): ?>
          <option value="<?php echo e($c); ?>" <?php if($c===$formCat) echo 'selected'; ?>>
            <?php echo e($c); ?>
          </option>
        <?php endforeach; ?>
        <option value="__new__">+ Crear nueva categoría...</option>
      </select>
      <input name="categoria_nueva" id="categoriaNueva"
             placeholder="Nombre nueva categoría"
             style="display:none;margin-top:6px;">
    </div>

    <div>
      <label>Tipo</label>
      <select name="tipo" required>
        <?php foreach($tiposAll as $t): ?>
          <option value="<?php echo e($t); ?>" <?php if($t===$formTipo) echo 'selected'; ?>>
            <?php echo e($t); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label>Precio default</label>
      <input type="number" min="0" step="1" name="precio" value="<?php echo (int)$formPrecio; ?>">
    </div>

    <div>
      <label>Cantidad default</label>
      <input type="number" min="0" step="1" name="cantidad" value="<?php echo (int)$formCant; ?>">
    </div>

    <div>
      <label>Hora límite</label>
      <input type="time" name="hora_limite" value="<?php echo e($formHora); ?>">
    </div>

    <div style="grid-column:1 / -1;">
      <label>Descripción (texto libre)</label>
      <textarea name="descripcion" rows="2"><?php echo e($formDesc); ?></textarea>
    </div>

    <div style="grid-column:1 / -1;display:flex;gap:10px;align-items:center;">
      <label style="margin:0;display:flex;gap:6px;align-items:center;">
        <input type="checkbox" name="activo" <?php 
        Activa
      </label>

      <span style="flex:1 1 auto;"></span>

      <button class="btn secondary" type="submit">
        <?php echo $editing ? "Guardar cambios" : "Crear plantilla"; ?>
      </button>

      <?php if($editing): ?>
        <a class="btn danger" href="plantillas_entrada.php">Cancelar</a>
      <?php ef; ?>
    </div>
  </form>
</div>

<div class="card">
  <h2>Plantillas guardadas</h2>

  <?php if (empty($plantillas)): ?>
    <div class="muted">Todavía no creaste plantillas.</div>
  <?php else: ?>
    <table class="table" style="margin-top:8px;">
      <thead>
        <tr>
          <th>ID</th>
          <th>Categoría</th>
          <th>Nombre</th>
          <th>Tipo</th>
          <th>Precio</th>
          <th>Cantidad</th>
          <th>Hora límite</th>
          <th>Estado</th>
          <th style="width:120px;">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($plantillas as $p): ?>
          <tr>
            <td><?php echo (int)$p['id']; ?></td>
            <td><?php echo e($p['categoria']); ?></td>
            <td><?php echo e($p['nombre']); ?></td>
            <td><?php echo e($p['tipo']); ?></td>
            <td>$<?php echo (int)$p['precio_default']; ?></td>
            <td><?php echo (int)$p['cantidad_default']; ?></td>
            <td><?php echo e($p['hora_limite_default']); ?></td>
            <td>
              <?php if ((int)$p['activo']===1): ?>
                <span class="badge-ok">Activa</span>
              <?php else: ?>
                <span class="badge-pend">Inactiva</span>
              <?php endif; ?>
            </td>
            <td style="white-space:nowrap;">
              <a class="btn secondary" style="padding:6px 10px;font-size:12px;"
                 href="plantillas_entrada.php?edit_id=<?php echo (int)$p['id']; ?>">✏️</a>

              <a class="btn danger" style="padding:6px 10px;font-size:12px;"
                 href="plantillas_entrada.php?del_id=<?php echo (int)$p['id']; ?>"
                 onclick="return confirm('¿Eliminar plantilla <?php echo e($p['nombre']); ?>?');">🗑️</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<script>
(function(){
  var sel = document.getElementById('categoriaSelect');
  var inp = document.getElementById('categoriaNueva');
  if(!sel || !inp) return;

  function toggle(){
    if(sel.value==='__new__'){
      inp.style.display='block';
      inp.required=true;
      inp.focus();
    }else{
      inp.style.display='none';
      inp.required=false;
      inp.value='';
    }
  }
  sel.addEventListener('change', toggle);
  toggle();
})();
</script>

<?php include __DIR__.'/inc/layout_bottom.php'; ?>
