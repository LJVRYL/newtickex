<?php
// mi_perfil.php - Perfil básico del admin, estilo crear_evento.php
// (sin upload de avatar por ahora, solo datos de texto)

require __DIR__ . '/inc/bootstrap.php';

// Requiere login
require_login();

$cu = current_user();
$tipoGlobal = isset($_SESSION['tipo_global'])
    ? $_SESSION['tipo_global']
    : (isset($cu['rol']) ? $cu['rol'] : '');

$userId = isset($cu['id'])
    ? (int)$cu['id']
    : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0);

if ($userId <= 0) {
    http_response_code(403);
    $title = 'Sesion invalida';
    require __DIR__ . '/inc/layout_top.php';
    echo '<div class="card"><div class="alert alert-danger">Sesion invalida (falta user_id).</div></div>';
    require __DIR__ . '/inc/layout_bottom.php';
    exit;
}

// Conectar DB via helper
try {
    $pdo = db();
} catch (Exception $e) {
    http_response_code(500);
    echo 'Error DB: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    exit;
}

// Cargar usuario en usuarios_admin
$user = null;
try {
    $stmt = $pdo->prepare(
        'SELECT id, username, tipo_global, nombre, email, dni, cbu
         FROM usuarios_admin
         WHERE id = :id
         LIMIT 1'
    );
    $stmt->execute(array(':id' => $userId));
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    http_response_code(500);
    echo 'Error cargando usuario.';
    exit;
}

if (!$user) {
    http_response_code(403);
    $title = 'Usuario no encontrado';
    require __DIR__ . '/inc/layout_top.php';
    echo '<div class="card"><div class="alert alert-danger">Usuario no encontrado.</div></div>';
    require __DIR__ . '/inc/layout_bottom.php';
    exit;
}

$error = '';
$okMsg = '';

// Procesar formulario (solo texto)
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $email  = isset($_POST['email'])  ? trim($_POST['email'])  : '';
    $dni    = isset($_POST['dni'])    ? trim($_POST['dni'])    : '';
    $cbu    = isset($_POST['cbu'])    ? trim($_POST['cbu'])    : '';

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'El email no tiene un formato valido.';
    }

    if ($error === '') {
        try {
            $stmtUpd = $pdo->prepare(
                'UPDATE usuarios_admin
                 SET nombre = :nombre,
                     email  = :email,
                     dni    = :dni,
                     cbu    = :cbu
                 WHERE id = :id'
            );
            $stmtUpd->execute(array(
                ':nombre' => ($nombre !== '' ? $nombre : null),
                ':email'  => ($email  !== '' ? $email  : null),
                ':dni'    => ($dni    !== '' ? $dni    : null),
                ':cbu'    => ($cbu    !== '' ? $cbu    : null),
                ':id'     => (int)$user['id'],
            ));

            $okMsg = 'Perfil actualizado correctamente.';

            // Refrescar datos en memoria
            $user['nombre'] = $nombre;
            $user['email']  = $email;
            $user['dni']    = $dni;
            $user['cbu']    = $cbu;
        } catch (Exception $e) {
            $error = 'Error al guardar el perfil.';
        }
    }
}

// Layout
$title = 'Mi perfil';
require __DIR__ . '/inc/layout_top.php';
?>
<div class="card" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
  <a class="btn secondary" href="panel_admin.php">⬅ Volver al panel</a>
</div>

<div class="card">
  <h2>Mi perfil</h2>
  <div style="color:var(--muted);font-size:14px;">
    Usuario: <strong><?php echo e($user['username']); ?></strong>
<?php if ($okMsg !== ''): ?>
  <div class="card">
    <div class="alert alert-success">
      <?php echo e($okMsg); ?>
    </div>
  </div>
<?php endif; ?>

<?php if ($error !== ''): ?>
  <div class="card">
    <div class="alert alert-danger">
      <?php echo e($error); ?>
    </div>
  </div>
<?php endif; ?>

<form method="post">
  <div class="card">
    <h3>Datos del perfil</h3>

    <label for="nombre">Nombre</label>
    <input type="text" id="nombre" name="nombre"
           value="<?php echo e($user['nombre']); ?>">

    <label for="email">Email</label>
    <input type="email" id="email" name="email"
           value="<?php echo e($user['email']); ?>">

    <label for="dni">DNI / Documento</label>
    <input type="text" id="dni" name="dni"
           value="<?php echo e($user['dni']); ?>">

    <label for="cbu">CBU / Cuenta para pagos</label>
    <input type="text" id="cbu" name="cbu"
           value="<?php echo e($user['cbu']); ?>">

    <button type="submit" class="btn" style="margin-top:12px;">
      Guardar cambios
    </button>
  </div>
</form>

<?php
require __DIR__ . '/inc/layout_bottom.php';
